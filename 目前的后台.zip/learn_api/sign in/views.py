from rest_framework.views import APIView
from rest_framework.authentication import SessionAuthentication
from rest_framework.status import (
    HTTP_200_OK,
    HTTP_201_CREATED,
    HTTP_400_BAD_REQUEST,
    HTTP_404_NOT_FOUND,
)
from rest_framework.permissions import (
    IsAuthenticated,
    AllowAny,

)
from .serializer import SignInCreateSerializer
from django.contrib.auth.decorators import permission_required


class SignInPublishView(APIView):
    serializer_class = SignInCreateSerializer
    permission_classes = [IsAuthenticated]
    authentication_classes = [SessionAuthentication]

    def post(self, request):
        serializer = SignInCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        is_time = serializer.validated_data['is_time']
        group =