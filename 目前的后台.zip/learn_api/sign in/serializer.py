from rest_framework.serializers import (
    CharField,
    EmailField,
    ImageField,
    HyperlinkedIdentityField,
    ModelSerializer,
    SerializerMethodField,
    ValidationError
)
from .models import SignIn


class SignInCreateSerializer(ModelSerializer):

    class Meta:
        model = SignIn
        field = [
            'is_time',
        ]