from django.db import models
from django.contrib.auth.models import User, Group
from django.utils import timezone
from post_q.models import Question
# Create your models here.


class SignIn(models.Model):

    group = models.ForeignKey(Group)
    is_time = models.BooleanField(default=False)
