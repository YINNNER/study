from django.contrib import admin
from .models import WHU
# Register your models here.

admin.site.register(WHU)