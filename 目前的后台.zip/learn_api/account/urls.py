from django.conf.urls import url,include
from .views import (UserLoginView,
                     UserDetailView, StuUserCreateView, ProUserCreateView,YzmView)



urlpatterns = [
    url(r'^detail/$', UserDetailView.as_view(), name='user_detail'),
    url(r'^login/$', UserLoginView.as_view(), name='login'),
    url(r'^stu_register/$', StuUserCreateView.as_view(), name='stu_reg'),
    url(r'^Pro_register/$', ProUserCreateView.as_view(), name='pro_reg'),
    url(r'^yzm/', YzmView.as_view(), name='yzm'),
    #url(r'^sign/', SignInPublishView.as_view(), name='sign'),
]
