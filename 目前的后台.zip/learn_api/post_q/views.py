from django.shortcuts import render
from rest_framework.permissions import (
    IsAuthenticated,
    AllowAny,

)
from .models import Course, Question, Post, Comment
from .serializers import (
    QuestionCreateSerializer,
    QuestionDetailSerializer,
    PostCreateSerializer,
    PostDetailSerializer,
    CourseCreateSerializer,
    CourseDetailSerializer,
    CommentCreateSerializer,
    CommentDetailSerializer,
    JoinCourseSerializer,
    FindCourseSerializer,
    GroupDetailSerializer,
)
from rest_framework.views import APIView
from rest_framework.authentication import SessionAuthentication
from rest_framework.status import (
    HTTP_200_OK,
    HTTP_201_CREATED,
    HTTP_400_BAD_REQUEST,
    HTTP_404_NOT_FOUND,
)
from rest_framework.response import Response
from .paginator import getPages
from django.contrib.auth.models import Group
# Create your views here.


class QuestionView(APIView):
    serializer_class = QuestionCreateSerializer
    permission_classes = [IsAuthenticated]
    authentication_classes = [SessionAuthentication]

    def post(self, request):
        serializer = QuestionCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        title = serializer.validated_data['title']
        content = serializer.validated_data['content']
        user = request.user
        question = Question.objects.create(author=user, title=title, content=content)
        question.save()
        reply = {"msg": "Create Question Successfully"}
        response = Response(reply, HTTP_200_OK)
        return response

    def get(self, request):
        #current_page = request.GET.get("page", 1)
        queryset = Question.objects.all().order_by('-created')
        #pages, posts = getPages(request, queryset)
        serializer = QuestionDetailSerializer(queryset, data=request.data, many=True)
        serializer.is_valid(raise_exception=True)
        response = Response(serializer.data, HTTP_200_OK)
        return response


class QuestionDetailView(APIView):
    permission_classes = [IsAuthenticated]
    content = {}
    def get(self, request, pk):
        question = Question.objects.filter(pk=pk)
        if len(question) == 0:
            content = {'error': "Can't find the question"}
            response = Response(content, HTTP_404_NOT_FOUND)
            return response
        serializer = QuestionDetailSerializer(question, data=request.data, many=True)
        if serializer.is_valid(raise_exception=True):
            response = Response(serializer.data, HTTP_200_OK)
            return response
        else:
            return Response(serializer.errors, HTTP_400_BAD_REQUEST)


class PostView(APIView):
    serializer_class = PostCreateSerializer
    permission_classes = [IsAuthenticated]
    authentication_classes = [SessionAuthentication]

    def post(self, request):
        serializer = PostCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        title = serializer.validated_data['title']
        content = serializer.validated_data['content']
        course = serializer.validated_data['course']
        files = serializer.validated_data['files']
        user = request.user
        posts = Post.objects.create(author=user, title=title, content=content, course=course, files=files)
        posts.save()
        reply = {"msg": "Create Question Successfully"}
        response = Response(reply, HTTP_200_OK)
        return response

    def get(self, request):
        queryset = Post.objects.all().order_by('-created')
        serializer = PostDetailSerializer(queryset, data=request.data, many=True)
        serializer.is_valid(raise_exception=True)
        response = Response(serializer.data, HTTP_200_OK)
        return response


class PostDetailView(APIView):
    permission_classes = [IsAuthenticated]
    content = {}

    def get(self, request, pk):
        posts = Post.objects.filter(pk=pk)
        if len(posts) == 0:
            content = {'error': "Can't find the post"}
            response = Response(content, HTTP_404_NOT_FOUND)
            return response
        serializer = PostDetailSerializer(posts, data=request.data, many=True)
        if serializer.is_valid(raise_exception=True):
            response = Response(serializer.data, HTTP_200_OK)
            return response
        else:
            return Response(serializer.errors, HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        user = request.user
        try:
            posts = Post.objects.get(user=user,pk=pk)
            try:
                posts.delete()
                content = {'msg': 'Delete Successfully'}
                response = Response(content, HTTP_200_OK)
                return response
            except:
                content = {'msg': 'Delete failed'}
                response = Response(content, HTTP_400_BAD_REQUEST)
                return response
        except Post.DoesNotExist:
            content = {'msg': "Can't find the post"}
            response = Response(content, HTTP_400_BAD_REQUEST)
            return response


class CourseView(APIView):
    serializer_class = CourseCreateSerializer
    permission_classes = [IsAuthenticated]
    authentication_classes = [SessionAuthentication]

    def post(self, request):
        serializer = CourseCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        name = serializer.validated_data['name']
        content = serializer.validated_data['content']
        teacher = request.user
        course = Course.objects.create(teacher=teacher, name=name, content=content)
        course.save()
        course_group = Group.objects.create(name=name+'-'+teacher.username)
        teacher.groups.add(course_group)
        reply = {'msg': 'Create course successfully'}
        response = Response(reply, HTTP_200_OK)
        return response

    def get(self, request):
        queryset = Course.objects.all()
        serializer = CourseDetailSerializer(queryset, data=request.data, many=True)
        serializer.is_valid(raise_exception=True)
        response = Response(serializer.data, HTTP_200_OK)
        return response


class CourseDetailView(APIView):
    permission_classes = [IsAuthenticated]
    content = {}

    def get(self, request, pk):
        course = Course.objects.filter(pk=pk)
        if len(course) == 0:
            content = {'error': "Can't find the course"}
            response = Response(content, HTTP_404_NOT_FOUND)
            return response
        serializer = CourseDetailSerializer(course, data=request.data, many=True)
        if serializer.is_valid(raise_exception=True):
            response = Response(serializer.data, HTTP_200_OK)
            return response
        else:
            return Response(serializer.errors, HTTP_400_BAD_REQUEST)


class CommentCreateView(APIView):
    serializer_class = CommentCreateSerializer
    permission_classes = [IsAuthenticated]
    authentication_classes = [SessionAuthentication]

    def post(self, request):
        serializer = CommentCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        content = serializer.validated_data['content']
        question = serializer.validated_data['question']
        user = request.user
        comments = Comment.objects.create(author=user, content=content, question=question)
        comments.save()
        reply = {'msg': 'Create Successfully'}
        response = Response(reply, HTTP_200_OK)
        return response

    def get(self, request):
        queryset = Comment.objects.all()
        serializer = CommentDetailSerializer(queryset, data=request.data, many=True)
        serializer.is_valid(raise_exception=True)
        response = Response(serializer.data, HTTP_200_OK)
        return response

class CommentDetailView(APIView):

    permission_classes = [IsAuthenticated]
    content = {}

    def get(self, request, pk):
        course = Comment.objects.filter(pk=pk)
        if len(course) == 0:
            content = {'error': "Can't find the course"}
            response = Response(content, HTTP_404_NOT_FOUND)
            return response
        serializer = CommentDetailSerializer(course, data=request.data, many=True)
        if serializer.is_valid(raise_exception=True):
            response = Response(serializer.data, HTTP_200_OK)
            return response
        else:
            return Response(serializer.errors, HTTP_400_BAD_REQUEST)

class FindCourseView(APIView):
    permission_classes = [IsAuthenticated]
    serializer_class = FindCourseSerializer
    authentication_classes = [SessionAuthentication]

    def post(self, request):
        serializer = FindCourseSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        name = serializer.validated_data['name']
        queryset = Course.objects.filter(name=name)
        serializer = CourseDetailSerializer(queryset, data=request.data, many=True)
        serializer.is_valid(raise_exception=True)
        response = Response(serializer.data, HTTP_200_OK)
        return response

    def get(self, request):
        queryset = Course.objects.all()
        serializer = CourseDetailSerializer(queryset, data=request.data, many=True)
        serializer.is_valid(raise_exception=True)
        response = Response(serializer.data, HTTP_200_OK)
        return response

class AddCourseView(APIView):
    serializer_class = JoinCourseSerializer
    permission_classes = [IsAuthenticated]
    authentication_classes = [SessionAuthentication]

    def post(self, request):
        serializer = JoinCourseSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        name = serializer.validated_data['name']
        teacher = serializer.validated_data['teacher']
        cs = Group.objects.get(name=name+'-'+teacher.username)
        user = request.user
        user.groups.add(cs)
        reply = {'msg': 'Join successfully'}
        response = Response(reply, HTTP_200_OK)
        return response

    def get(self, request):
        queryset = Group.objects.all()
        serializer = GroupDetailSerializer(queryset, data=request.data, many=True)
        serializer.is_valid(raise_exception=True)
        response = Response(serializer.data, HTTP_200_OK)
        return response
