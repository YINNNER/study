from django.conf.urls import url,include
from .views import (QuestionView,
                    QuestionDetailView,
                    PostDetailView,
                    PostView,
                    CourseView,
                    CourseDetailView,
                    CommentCreateView,
                    CommentDetailView,
                    AddCourseView,
                    FindCourseView,
                    )
urlpatterns = [
    url(r'^post/$', PostView.as_view(), name='p_create_list'),
    url(r'^post/(?P<pk>\d+)', PostDetailView.as_view(), name='p_detail_delete'),
    url(r'^question/$', QuestionView.as_view(), name='q_create_list'),
    url(r'^question/(?P<pk>\d+)', QuestionDetailView.as_view(), name='q_detail_delete'),
    url(r'^course/$', CourseView.as_view(), name='q_create_list'),
    url(r'^course/(?P<pk>\d+)', CourseDetailView.as_view(), name='q_create_list'),
    url(r'^comment/$', CommentCreateView.as_view(), name='q_create_list'),
    #url(r'^comment/(?P<pk>\d+)', CommentDetailView.as_view(), name='q_create_list'),
    url(r'^add_course/', AddCourseView.as_view(), name='f_course'),
    url(r'^f_course/', FindCourseView.as_view(), name='f_course'),
]