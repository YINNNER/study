from django.apps import AppConfig


class PostQConfig(AppConfig):
    name = 'post_q'
